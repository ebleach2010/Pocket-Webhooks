# The owner's standing rules

These come from Eric, most of them in his own words over many weeks. They are all still in force. The full set, with dates, is in `CLAUDE.md` in the repo.

## Secrets and privacy

- Never handle, print, ask for or repeat an API key, password, PIN, one-time code or token. Guide clicks only. Keys go from the site that made them straight into his password manager or a Cloudflare encrypted secret.
- Never repeat a client's name or details seen in a screenshot, document or the database. Use the practice copy's made-up people in tests, pictures and reports.
- Nothing about clients, the waitlist, or anything behind sign-in may appear in public code or public pages.
- Arielle's work email is private. It must never appear in the repo, in public code, commits, pull requests, documents or pictures, and is never hard-coded.
- The investor is always called "the investor". His name is never used anywhere, including payroll.
- The owner's own private files are never read by the helpers. Intake answers are never sent to them.
- The D-U-N-S number stays out of the repo and public code.
- Contractor documents are readable only by the owner and that contractor.
- Never sign in to, or write to, the live site. Signed-out page loads are fine. Never change his live data, prices or switches for him.
- Do not use the word "HIPAA" anywhere under `public/`.

## What clients may see

- **Clients see nothing about how the product is made.** No mention of AI, a model, a chatbot, or a vendor name in anything a client can read. The blindness audit enforces this.
- The same list of words is banned in the staff-facing release notes (`worker/devnotes.js`): "Advisor" and "differential" as words about the tools, "AI", "LLM", "language model", "the model", "a model", "chatbot", and vendor and model names.
- Narration in tours never describes the narrator as an AI or as Eric.
- Staff are told (his exact words, 2026-11-18): "Please do not mention the Bookkeeper or Advisor to clients in any form. If a client asks, don't deny it. Just let Eric know. This is part of keeping trade secrets safe."

## Legal text, prices and consent

- Legal text (Terms, Privacy, agreements, contractor papers) changes only on Eric's word, with his exact wording. Each change is a new dated version; the old text is kept word for word.
- Never force existing clients to agree to new terms without asking him first. New versions normally apply to new bookings only.
- Prices change only on his word. Prices shown to the public are read live from `/api/rates`, never hard-coded.
- His own story text is never edited, only formatted.
- Never invent his or Arielle's story or credentials.
- United States only.
- The phone number is written "(208) 508-4094" and nothing else.

## How to work

- Full test battery before any push to `main`.
- Build first, ask correcting questions after. If very unsure, hold that part until he answers.
- Ask questions as short multiple choice he can tap. Never more than four at once.
- He gave a standing go-ahead to put verified work live without waiting for him to look at pictures, because he is not advertising yet. Still needed from him each time: legal wording, prices, anything that makes people agree again.
- Tell him the exact path to every new control.
- Alert him when something goes live.
- Status lists use his markers: 🔴 live, ✅ done and waiting for his approval, 🟡 in progress, 🚨 needs his answer, ‼️ blocking a build.
- "/suite X" means show him the checks for X. "/optimizeUI" means do a real hands-on sweep of the screens.

## Writing for people

- Warm, plain words, about a tenth-grade reading level. Say "please".
- No en dashes or em dashes in any text added to the app.
- Staff-side wording: friendly and plain. Client side: warm.

## Code rules

- Frozen files, never edited: `public/js/folder.js`, `drawer.js`, `advisor.js`, `waivers.js`; `public/css/site.css`, `look.css`.
- Commits are authored `Claude <noreply@anthropic.com>` with the two trailers in `CLAUDE.md`. No model names in commits, pull requests or code. (A different tool should agree its own commit identity with Eric.)
- Every case route checks whose case it is. A second advocate sees a case only through `teamSees`, never by widening `staffSees`.
- When a test fails because the design changed on his word, update the test in the same commit and say so. Never delete a check.
- Every re-pinned check needs a negative control that was actually run.
